gdjs.judulCode = {};
gdjs.judulCode.GDNewTiledSpriteObjects1= [];
gdjs.judulCode.GDNewTiledSpriteObjects2= [];
gdjs.judulCode.GDNewTextObjects1= [];
gdjs.judulCode.GDNewTextObjects2= [];
gdjs.judulCode.GDNewText2Objects1= [];
gdjs.judulCode.GDNewText2Objects2= [];
gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1= [];
gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects2= [];
gdjs.judulCode.GDgagahObjects1= [];
gdjs.judulCode.GDgagahObjects2= [];
gdjs.judulCode.GDgagah2Objects1= [];
gdjs.judulCode.GDgagah2Objects2= [];
gdjs.judulCode.GDgagah3Objects1= [];
gdjs.judulCode.GDgagah3Objects2= [];


gdjs.judulCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.judulCode.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.judulCode.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.judulCode.GDNewTiledSpriteObjects1[i].setXOffset(gdjs.judulCode.GDNewTiledSpriteObjects1[i].getXOffset() + (0 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquareDecoratedButton"), gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1[k] = gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "dialog", false);
}}

}


};

gdjs.judulCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.judulCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.judulCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.judulCode.GDNewTextObjects1.length = 0;
gdjs.judulCode.GDNewTextObjects2.length = 0;
gdjs.judulCode.GDNewText2Objects1.length = 0;
gdjs.judulCode.GDNewText2Objects2.length = 0;
gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.judulCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.judulCode.GDgagahObjects1.length = 0;
gdjs.judulCode.GDgagahObjects2.length = 0;
gdjs.judulCode.GDgagah2Objects1.length = 0;
gdjs.judulCode.GDgagah2Objects2.length = 0;
gdjs.judulCode.GDgagah3Objects1.length = 0;
gdjs.judulCode.GDgagah3Objects2.length = 0;

gdjs.judulCode.eventsList0(runtimeScene);

return;

}

gdjs['judulCode'] = gdjs.judulCode;
