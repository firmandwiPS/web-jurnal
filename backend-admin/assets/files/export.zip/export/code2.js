gdjs.Level1Code = {};
gdjs.Level1Code.forEachCount0_5 = 0;

gdjs.Level1Code.forEachCount10_5 = 0;

gdjs.Level1Code.forEachCount11_5 = 0;

gdjs.Level1Code.forEachCount12_5 = 0;

gdjs.Level1Code.forEachCount13_5 = 0;

gdjs.Level1Code.forEachCount14_5 = 0;

gdjs.Level1Code.forEachCount15_5 = 0;

gdjs.Level1Code.forEachCount1_5 = 0;

gdjs.Level1Code.forEachCount2_5 = 0;

gdjs.Level1Code.forEachCount3_5 = 0;

gdjs.Level1Code.forEachCount4_5 = 0;

gdjs.Level1Code.forEachCount5_5 = 0;

gdjs.Level1Code.forEachCount6_5 = 0;

gdjs.Level1Code.forEachCount7_5 = 0;

gdjs.Level1Code.forEachCount8_5 = 0;

gdjs.Level1Code.forEachCount9_5 = 0;

gdjs.Level1Code.forEachIndex3 = 0;

gdjs.Level1Code.forEachIndex5 = 0;

gdjs.Level1Code.forEachObjects3 = [];

gdjs.Level1Code.forEachObjects5 = [];

gdjs.Level1Code.forEachTemporary3 = null;

gdjs.Level1Code.forEachTotalCount3 = 0;

gdjs.Level1Code.forEachTotalCount5 = 0;

gdjs.Level1Code.GDcard_9595crabObjects1= [];
gdjs.Level1Code.GDcard_9595crabObjects2= [];
gdjs.Level1Code.GDcard_9595crabObjects3= [];
gdjs.Level1Code.GDcard_9595crabObjects4= [];
gdjs.Level1Code.GDcard_9595crabObjects5= [];
gdjs.Level1Code.GDcard_9595crabObjects6= [];
gdjs.Level1Code.GDcard_9595crabObjects7= [];
gdjs.Level1Code.GDcard_9595crab2Objects1= [];
gdjs.Level1Code.GDcard_9595crab2Objects2= [];
gdjs.Level1Code.GDcard_9595crab2Objects3= [];
gdjs.Level1Code.GDcard_9595crab2Objects4= [];
gdjs.Level1Code.GDcard_9595crab2Objects5= [];
gdjs.Level1Code.GDcard_9595crab2Objects6= [];
gdjs.Level1Code.GDcard_9595crab2Objects7= [];
gdjs.Level1Code.GDcard_9595seahorseObjects1= [];
gdjs.Level1Code.GDcard_9595seahorseObjects2= [];
gdjs.Level1Code.GDcard_9595seahorseObjects3= [];
gdjs.Level1Code.GDcard_9595seahorseObjects4= [];
gdjs.Level1Code.GDcard_9595seahorseObjects5= [];
gdjs.Level1Code.GDcard_9595seahorseObjects6= [];
gdjs.Level1Code.GDcard_9595seahorseObjects7= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects1= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects2= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects3= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects4= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects5= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects6= [];
gdjs.Level1Code.GDcard_9595seahorse2Objects7= [];
gdjs.Level1Code.GDcard_9595snailObjects1= [];
gdjs.Level1Code.GDcard_9595snailObjects2= [];
gdjs.Level1Code.GDcard_9595snailObjects3= [];
gdjs.Level1Code.GDcard_9595snailObjects4= [];
gdjs.Level1Code.GDcard_9595snailObjects5= [];
gdjs.Level1Code.GDcard_9595snailObjects6= [];
gdjs.Level1Code.GDcard_9595snailObjects7= [];
gdjs.Level1Code.GDcard_9595snail2Objects1= [];
gdjs.Level1Code.GDcard_9595snail2Objects2= [];
gdjs.Level1Code.GDcard_9595snail2Objects3= [];
gdjs.Level1Code.GDcard_9595snail2Objects4= [];
gdjs.Level1Code.GDcard_9595snail2Objects5= [];
gdjs.Level1Code.GDcard_9595snail2Objects6= [];
gdjs.Level1Code.GDcard_9595snail2Objects7= [];
gdjs.Level1Code.GDcard_9595seagrassObjects1= [];
gdjs.Level1Code.GDcard_9595seagrassObjects2= [];
gdjs.Level1Code.GDcard_9595seagrassObjects3= [];
gdjs.Level1Code.GDcard_9595seagrassObjects4= [];
gdjs.Level1Code.GDcard_9595seagrassObjects5= [];
gdjs.Level1Code.GDcard_9595seagrassObjects6= [];
gdjs.Level1Code.GDcard_9595seagrassObjects7= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects1= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects2= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects3= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects4= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects5= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects6= [];
gdjs.Level1Code.GDcard_9595seagrass2Objects7= [];
gdjs.Level1Code.GDcard_9595coralObjects1= [];
gdjs.Level1Code.GDcard_9595coralObjects2= [];
gdjs.Level1Code.GDcard_9595coralObjects3= [];
gdjs.Level1Code.GDcard_9595coralObjects4= [];
gdjs.Level1Code.GDcard_9595coralObjects5= [];
gdjs.Level1Code.GDcard_9595coralObjects6= [];
gdjs.Level1Code.GDcard_9595coralObjects7= [];
gdjs.Level1Code.GDcard_9595coral2Objects1= [];
gdjs.Level1Code.GDcard_9595coral2Objects2= [];
gdjs.Level1Code.GDcard_9595coral2Objects3= [];
gdjs.Level1Code.GDcard_9595coral2Objects4= [];
gdjs.Level1Code.GDcard_9595coral2Objects5= [];
gdjs.Level1Code.GDcard_9595coral2Objects6= [];
gdjs.Level1Code.GDcard_9595coral2Objects7= [];
gdjs.Level1Code.GDcard_9595anemoneObjects1= [];
gdjs.Level1Code.GDcard_9595anemoneObjects2= [];
gdjs.Level1Code.GDcard_9595anemoneObjects3= [];
gdjs.Level1Code.GDcard_9595anemoneObjects4= [];
gdjs.Level1Code.GDcard_9595anemoneObjects5= [];
gdjs.Level1Code.GDcard_9595anemoneObjects6= [];
gdjs.Level1Code.GDcard_9595anemoneObjects7= [];
gdjs.Level1Code.GDcard_9595anemone2Objects1= [];
gdjs.Level1Code.GDcard_9595anemone2Objects2= [];
gdjs.Level1Code.GDcard_9595anemone2Objects3= [];
gdjs.Level1Code.GDcard_9595anemone2Objects4= [];
gdjs.Level1Code.GDcard_9595anemone2Objects5= [];
gdjs.Level1Code.GDcard_9595anemone2Objects6= [];
gdjs.Level1Code.GDcard_9595anemone2Objects7= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects1= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects2= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects3= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects4= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects5= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects6= [];
gdjs.Level1Code.GDcard_9595plasticbagObjects7= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects1= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects2= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects3= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects4= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects5= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects6= [];
gdjs.Level1Code.GDcard_9595plasticbag2Objects7= [];
gdjs.Level1Code.GDcard_9595blowfishObjects1= [];
gdjs.Level1Code.GDcard_9595blowfishObjects2= [];
gdjs.Level1Code.GDcard_9595blowfishObjects3= [];
gdjs.Level1Code.GDcard_9595blowfishObjects4= [];
gdjs.Level1Code.GDcard_9595blowfishObjects5= [];
gdjs.Level1Code.GDcard_9595blowfishObjects6= [];
gdjs.Level1Code.GDcard_9595blowfishObjects7= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects1= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects2= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects3= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects4= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects5= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects6= [];
gdjs.Level1Code.GDcard_9595blowfish2Objects7= [];
gdjs.Level1Code.GDposition_9595placeholderObjects1= [];
gdjs.Level1Code.GDposition_9595placeholderObjects2= [];
gdjs.Level1Code.GDposition_9595placeholderObjects3= [];
gdjs.Level1Code.GDposition_9595placeholderObjects4= [];
gdjs.Level1Code.GDposition_9595placeholderObjects5= [];
gdjs.Level1Code.GDposition_9595placeholderObjects6= [];
gdjs.Level1Code.GDposition_9595placeholderObjects7= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects1= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects2= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects3= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects4= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects5= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects6= [];
gdjs.Level1Code.GDnewgame_9595buttonObjects7= [];
gdjs.Level1Code.GDboardObjects1= [];
gdjs.Level1Code.GDboardObjects2= [];
gdjs.Level1Code.GDboardObjects3= [];
gdjs.Level1Code.GDboardObjects4= [];
gdjs.Level1Code.GDboardObjects5= [];
gdjs.Level1Code.GDboardObjects6= [];
gdjs.Level1Code.GDboardObjects7= [];
gdjs.Level1Code.GDpairsObjects1= [];
gdjs.Level1Code.GDpairsObjects2= [];
gdjs.Level1Code.GDpairsObjects3= [];
gdjs.Level1Code.GDpairsObjects4= [];
gdjs.Level1Code.GDpairsObjects5= [];
gdjs.Level1Code.GDpairsObjects6= [];
gdjs.Level1Code.GDpairsObjects7= [];
gdjs.Level1Code.GDnewgameObjects1= [];
gdjs.Level1Code.GDnewgameObjects2= [];
gdjs.Level1Code.GDnewgameObjects3= [];
gdjs.Level1Code.GDnewgameObjects4= [];
gdjs.Level1Code.GDnewgameObjects5= [];
gdjs.Level1Code.GDnewgameObjects6= [];
gdjs.Level1Code.GDnewgameObjects7= [];
gdjs.Level1Code.GDyouwonObjects1= [];
gdjs.Level1Code.GDyouwonObjects2= [];
gdjs.Level1Code.GDyouwonObjects3= [];
gdjs.Level1Code.GDyouwonObjects4= [];
gdjs.Level1Code.GDyouwonObjects5= [];
gdjs.Level1Code.GDyouwonObjects6= [];
gdjs.Level1Code.GDyouwonObjects7= [];
gdjs.Level1Code.GDstar_9595particleObjects1= [];
gdjs.Level1Code.GDstar_9595particleObjects2= [];
gdjs.Level1Code.GDstar_9595particleObjects3= [];
gdjs.Level1Code.GDstar_9595particleObjects4= [];
gdjs.Level1Code.GDstar_9595particleObjects5= [];
gdjs.Level1Code.GDstar_9595particleObjects6= [];
gdjs.Level1Code.GDstar_9595particleObjects7= [];
gdjs.Level1Code.GDscreen_9595fadeObjects1= [];
gdjs.Level1Code.GDscreen_9595fadeObjects2= [];
gdjs.Level1Code.GDscreen_9595fadeObjects3= [];
gdjs.Level1Code.GDscreen_9595fadeObjects4= [];
gdjs.Level1Code.GDscreen_9595fadeObjects5= [];
gdjs.Level1Code.GDscreen_9595fadeObjects6= [];
gdjs.Level1Code.GDscreen_9595fadeObjects7= [];
gdjs.Level1Code.GDui_9595backgroundObjects1= [];
gdjs.Level1Code.GDui_9595backgroundObjects2= [];
gdjs.Level1Code.GDui_9595backgroundObjects3= [];
gdjs.Level1Code.GDui_9595backgroundObjects4= [];
gdjs.Level1Code.GDui_9595backgroundObjects5= [];
gdjs.Level1Code.GDui_9595backgroundObjects6= [];
gdjs.Level1Code.GDui_9595backgroundObjects7= [];
gdjs.Level1Code.GDNewTiledSpriteObjects1= [];
gdjs.Level1Code.GDNewTiledSpriteObjects2= [];
gdjs.Level1Code.GDNewTiledSpriteObjects3= [];
gdjs.Level1Code.GDNewTiledSpriteObjects4= [];
gdjs.Level1Code.GDNewTiledSpriteObjects5= [];
gdjs.Level1Code.GDNewTiledSpriteObjects6= [];
gdjs.Level1Code.GDNewTiledSpriteObjects7= [];
gdjs.Level1Code.GDNewTiledSprite2Objects1= [];
gdjs.Level1Code.GDNewTiledSprite2Objects2= [];
gdjs.Level1Code.GDNewTiledSprite2Objects3= [];
gdjs.Level1Code.GDNewTiledSprite2Objects4= [];
gdjs.Level1Code.GDNewTiledSprite2Objects5= [];
gdjs.Level1Code.GDNewTiledSprite2Objects6= [];
gdjs.Level1Code.GDNewTiledSprite2Objects7= [];
gdjs.Level1Code.GDNewSpriteObjects1= [];
gdjs.Level1Code.GDNewSpriteObjects2= [];
gdjs.Level1Code.GDNewSpriteObjects3= [];
gdjs.Level1Code.GDNewSpriteObjects4= [];
gdjs.Level1Code.GDNewSpriteObjects5= [];
gdjs.Level1Code.GDNewSpriteObjects6= [];
gdjs.Level1Code.GDNewSpriteObjects7= [];
gdjs.Level1Code.GDDesertTileObjects1= [];
gdjs.Level1Code.GDDesertTileObjects2= [];
gdjs.Level1Code.GDDesertTileObjects3= [];
gdjs.Level1Code.GDDesertTileObjects4= [];
gdjs.Level1Code.GDDesertTileObjects5= [];
gdjs.Level1Code.GDDesertTileObjects6= [];
gdjs.Level1Code.GDDesertTileObjects7= [];
gdjs.Level1Code.GDpetunjukObjects1= [];
gdjs.Level1Code.GDpetunjukObjects2= [];
gdjs.Level1Code.GDpetunjukObjects3= [];
gdjs.Level1Code.GDpetunjukObjects4= [];
gdjs.Level1Code.GDpetunjukObjects5= [];
gdjs.Level1Code.GDpetunjukObjects6= [];
gdjs.Level1Code.GDpetunjukObjects7= [];
gdjs.Level1Code.GDCloseButtonObjects1= [];
gdjs.Level1Code.GDCloseButtonObjects2= [];
gdjs.Level1Code.GDCloseButtonObjects3= [];
gdjs.Level1Code.GDCloseButtonObjects4= [];
gdjs.Level1Code.GDCloseButtonObjects5= [];
gdjs.Level1Code.GDCloseButtonObjects6= [];
gdjs.Level1Code.GDCloseButtonObjects7= [];
gdjs.Level1Code.GDNewTextObjects1= [];
gdjs.Level1Code.GDNewTextObjects2= [];
gdjs.Level1Code.GDNewTextObjects3= [];
gdjs.Level1Code.GDNewTextObjects4= [];
gdjs.Level1Code.GDNewTextObjects5= [];
gdjs.Level1Code.GDNewTextObjects6= [];
gdjs.Level1Code.GDNewTextObjects7= [];
gdjs.Level1Code.GDcopyrightObjects1= [];
gdjs.Level1Code.GDcopyrightObjects2= [];
gdjs.Level1Code.GDcopyrightObjects3= [];
gdjs.Level1Code.GDcopyrightObjects4= [];
gdjs.Level1Code.GDcopyrightObjects5= [];
gdjs.Level1Code.GDcopyrightObjects6= [];
gdjs.Level1Code.GDcopyrightObjects7= [];
gdjs.Level1Code.GDNewSprite2Objects1= [];
gdjs.Level1Code.GDNewSprite2Objects2= [];
gdjs.Level1Code.GDNewSprite2Objects3= [];
gdjs.Level1Code.GDNewSprite2Objects4= [];
gdjs.Level1Code.GDNewSprite2Objects5= [];
gdjs.Level1Code.GDNewSprite2Objects6= [];
gdjs.Level1Code.GDNewSprite2Objects7= [];
gdjs.Level1Code.GDgameover_9595swObjects1= [];
gdjs.Level1Code.GDgameover_9595swObjects2= [];
gdjs.Level1Code.GDgameover_9595swObjects3= [];
gdjs.Level1Code.GDgameover_9595swObjects4= [];
gdjs.Level1Code.GDgameover_9595swObjects5= [];
gdjs.Level1Code.GDgameover_9595swObjects6= [];
gdjs.Level1Code.GDgameover_9595swObjects7= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects2= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects3= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects4= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects5= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects6= [];
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects7= [];
gdjs.Level1Code.GDNewSprite3Objects1= [];
gdjs.Level1Code.GDNewSprite3Objects2= [];
gdjs.Level1Code.GDNewSprite3Objects3= [];
gdjs.Level1Code.GDNewSprite3Objects4= [];
gdjs.Level1Code.GDNewSprite3Objects5= [];
gdjs.Level1Code.GDNewSprite3Objects6= [];
gdjs.Level1Code.GDNewSprite3Objects7= [];


gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.Level1Code.GDcard_9595blowfishObjects4, "card_crab": gdjs.Level1Code.GDcard_9595crabObjects4, "card_seahorse": gdjs.Level1Code.GDcard_9595seahorseObjects4, "card_snail": gdjs.Level1Code.GDcard_9595snailObjects4, "card_seagrass": gdjs.Level1Code.GDcard_9595seagrassObjects4, "card_coral": gdjs.Level1Code.GDcard_9595coralObjects4, "card_anemone": gdjs.Level1Code.GDcard_9595anemoneObjects4, "card_plasticbag": gdjs.Level1Code.GDcard_9595plasticbagObjects4, "card_blowfish2": gdjs.Level1Code.GDcard_9595blowfish2Objects4, "card_crab2": gdjs.Level1Code.GDcard_9595crab2Objects4, "card_seahorse2": gdjs.Level1Code.GDcard_9595seahorse2Objects4, "card_snail2": gdjs.Level1Code.GDcard_9595snail2Objects4, "card_seagrass2": gdjs.Level1Code.GDcard_9595seagrass2Objects4, "card_coral2": gdjs.Level1Code.GDcard_9595coral2Objects4, "card_anemone2": gdjs.Level1Code.GDcard_9595anemone2Objects4, "card_plasticbag2": gdjs.Level1Code.GDcard_9595plasticbag2Objects4});
gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects4Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */
/* Reuse gdjs.Level1Code.GDposition_9595placeholderObjects4 */
{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Level1Code.GDposition_9595placeholderObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDposition_9595placeholderObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects4[k] = gdjs.Level1Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects4[k] = gdjs.Level1Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects4[k] = gdjs.Level1Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects4[k] = gdjs.Level1Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects4[k] = gdjs.Level1Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects4[k] = gdjs.Level1Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects4[k] = gdjs.Level1Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects4[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects4[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects4[k] = gdjs.Level1Code.GDcard_9595crab2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects4[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects4[k] = gdjs.Level1Code.GDcard_9595snail2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects4[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects4[k] = gdjs.Level1Code.GDcard_9595coral2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects4[k] = gdjs.Level1Code.GDcard_9595anemone2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects4[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */
gdjs.copyArray(gdjs.Level1Code.GDposition_9595placeholderObjects3, gdjs.Level1Code.GDposition_9595placeholderObjects4);

{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Level1Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Level1Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
}
{ //Subevents
gdjs.Level1Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("position_placeholder"), gdjs.Level1Code.GDposition_9595placeholderObjects2);

for (gdjs.Level1Code.forEachIndex3 = 0;gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.GDposition_9595placeholderObjects2.length;++gdjs.Level1Code.forEachIndex3) {
gdjs.Level1Code.GDposition_9595placeholderObjects3.length = 0;


gdjs.Level1Code.forEachTemporary3 = gdjs.Level1Code.GDposition_9595placeholderObjects2[gdjs.Level1Code.forEachIndex3];
gdjs.Level1Code.GDposition_9595placeholderObjects3.push(gdjs.Level1Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Level1Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("screen_fade"), gdjs.Level1Code.GDscreen_9595fadeObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDscreen_9595fadeObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDscreen_9595fadeObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_in", 0, "linear", 1000, true);
}
}}

}


};gdjs.Level1Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Fade");
}
{ //Subevents
gdjs.Level1Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects2Objects = Hashtable.newFrom({"card_blowfish": gdjs.Level1Code.GDcard_9595blowfishObjects2, "card_crab": gdjs.Level1Code.GDcard_9595crabObjects2, "card_seahorse": gdjs.Level1Code.GDcard_9595seahorseObjects2, "card_snail": gdjs.Level1Code.GDcard_9595snailObjects2, "card_seagrass": gdjs.Level1Code.GDcard_9595seagrassObjects2, "card_coral": gdjs.Level1Code.GDcard_9595coralObjects2, "card_anemone": gdjs.Level1Code.GDcard_9595anemoneObjects2, "card_plasticbag": gdjs.Level1Code.GDcard_9595plasticbagObjects2, "card_blowfish2": gdjs.Level1Code.GDcard_9595blowfish2Objects2, "card_crab2": gdjs.Level1Code.GDcard_9595crab2Objects2, "card_seahorse2": gdjs.Level1Code.GDcard_9595seahorse2Objects2, "card_snail2": gdjs.Level1Code.GDcard_9595snail2Objects2, "card_seagrass2": gdjs.Level1Code.GDcard_9595seagrass2Objects2, "card_coral2": gdjs.Level1Code.GDcard_9595coral2Objects2, "card_anemone2": gdjs.Level1Code.GDcard_9595anemone2Objects2, "card_plasticbag2": gdjs.Level1Code.GDcard_9595plasticbag2Objects2});
gdjs.Level1Code.eventsList4 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "show_cards");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setString("show_cards");
}}

}


};gdjs.Level1Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemoneObjects2, gdjs.Level1Code.GDcard_9595anemoneObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemone2Objects2, gdjs.Level1Code.GDcard_9595anemone2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfishObjects2, gdjs.Level1Code.GDcard_9595blowfishObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfish2Objects2, gdjs.Level1Code.GDcard_9595blowfish2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coralObjects2, gdjs.Level1Code.GDcard_9595coralObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coral2Objects2, gdjs.Level1Code.GDcard_9595coral2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crabObjects2, gdjs.Level1Code.GDcard_9595crabObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crab2Objects2, gdjs.Level1Code.GDcard_9595crab2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbagObjects2, gdjs.Level1Code.GDcard_9595plasticbagObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbag2Objects2, gdjs.Level1Code.GDcard_9595plasticbag2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrassObjects2, gdjs.Level1Code.GDcard_9595seagrassObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrass2Objects2, gdjs.Level1Code.GDcard_9595seagrass2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorseObjects2, gdjs.Level1Code.GDcard_9595seahorseObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorse2Objects2, gdjs.Level1Code.GDcard_9595seahorse2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snailObjects2, gdjs.Level1Code.GDcard_9595snailObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snail2Objects2, gdjs.Level1Code.GDcard_9595snail2Objects3);

{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects3.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemoneObjects2, gdjs.Level1Code.GDcard_9595anemoneObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemone2Objects2, gdjs.Level1Code.GDcard_9595anemone2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfishObjects2, gdjs.Level1Code.GDcard_9595blowfishObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfish2Objects2, gdjs.Level1Code.GDcard_9595blowfish2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coralObjects2, gdjs.Level1Code.GDcard_9595coralObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coral2Objects2, gdjs.Level1Code.GDcard_9595coral2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crabObjects2, gdjs.Level1Code.GDcard_9595crabObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crab2Objects2, gdjs.Level1Code.GDcard_9595crab2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbagObjects2, gdjs.Level1Code.GDcard_9595plasticbagObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbag2Objects2, gdjs.Level1Code.GDcard_9595plasticbag2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrassObjects2, gdjs.Level1Code.GDcard_9595seagrassObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrass2Objects2, gdjs.Level1Code.GDcard_9595seagrass2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorseObjects2, gdjs.Level1Code.GDcard_9595seahorseObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorse2Objects2, gdjs.Level1Code.GDcard_9595seahorse2Objects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snailObjects2, gdjs.Level1Code.GDcard_9595snailObjects3);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snail2Objects2, gdjs.Level1Code.GDcard_9595snail2Objects3);

{runtimeScene.getScene().getVariables().getFromIndex(2).setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1Code.GDcard_9595plasticbag2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595anemone2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595coral2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seagrass2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595snail2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seahorse2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595crab2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595blowfish2Objects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595plasticbagObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595anemoneObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595coralObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seagrassObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595snailObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seahorseObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595crabObjects3.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595blowfishObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1Code.GDcard_9595blowfishObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595crabObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595seahorseObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595snailObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595seagrassObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595coralObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595anemoneObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595plasticbagObjects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595blowfish2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595crab2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595seahorse2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595snail2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595seagrass2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595coral2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595anemone2Objects3[0].getVariables()) : gdjs.Level1Code.GDcard_9595plasticbag2Objects3[0].getVariables()).get("id"))));
}
{ //Subevents
gdjs.Level1Code.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setString((gdjs.RuntimeObject.getVariableString(((gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595anemone2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595coral2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seagrass2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595snail2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seahorse2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595crab2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595blowfish2Objects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595plasticbagObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595anemoneObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595coralObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seagrassObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595snailObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595seahorseObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595crabObjects2.length === 0 ) ? ((gdjs.Level1Code.GDcard_9595blowfishObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Level1Code.GDcard_9595blowfishObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595crabObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595seahorseObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595snailObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595seagrassObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595coralObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595anemoneObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595plasticbagObjects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595blowfish2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595crab2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595seahorse2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595snail2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595seagrass2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595coral2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595anemone2Objects2[0].getVariables()) : gdjs.Level1Code.GDcard_9595plasticbag2Objects2[0].getVariables()).get("id"))));
}}

}


};gdjs.Level1Code.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects2ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects2[k] = gdjs.Level1Code.GDcard_9595blowfishObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects2[k] = gdjs.Level1Code.GDcard_9595crabObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects2[k] = gdjs.Level1Code.GDcard_9595seahorseObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects2[k] = gdjs.Level1Code.GDcard_9595snailObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects2[k] = gdjs.Level1Code.GDcard_9595seagrassObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects2[k] = gdjs.Level1Code.GDcard_9595coralObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects2[k] = gdjs.Level1Code.GDcard_9595anemoneObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects2[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects2[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects2[k] = gdjs.Level1Code.GDcard_9595crab2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects2[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects2[k] = gdjs.Level1Code.GDcard_9595snail2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects2[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects2[k] = gdjs.Level1Code.GDcard_9595coral2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects2[k] = gdjs.Level1Code.GDcard_9595anemone2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects2[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cockatrice_playcard.mp3", false, 100, 1);
}
{ //Subevents
gdjs.Level1Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects2 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects2 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects2 */
{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i].setAnimationName("front");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.Level1Code.GDcard_9595blowfishObjects4, "card_crab": gdjs.Level1Code.GDcard_9595crabObjects4, "card_seahorse": gdjs.Level1Code.GDcard_9595seahorseObjects4, "card_snail": gdjs.Level1Code.GDcard_9595snailObjects4, "card_seagrass": gdjs.Level1Code.GDcard_9595seagrassObjects4, "card_coral": gdjs.Level1Code.GDcard_9595coralObjects4, "card_anemone": gdjs.Level1Code.GDcard_9595anemoneObjects4, "card_plasticbag": gdjs.Level1Code.GDcard_9595plasticbagObjects4, "card_blowfish2": gdjs.Level1Code.GDcard_9595blowfish2Objects4, "card_crab2": gdjs.Level1Code.GDcard_9595crab2Objects4, "card_seahorse2": gdjs.Level1Code.GDcard_9595seahorse2Objects4, "card_snail2": gdjs.Level1Code.GDcard_9595snail2Objects4, "card_seagrass2": gdjs.Level1Code.GDcard_9595seagrass2Objects4, "card_coral2": gdjs.Level1Code.GDcard_9595coral2Objects4, "card_anemone2": gdjs.Level1Code.GDcard_9595anemone2Objects4, "card_plasticbag2": gdjs.Level1Code.GDcard_9595plasticbag2Objects4});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDstar_95959595particleObjects6Objects = Hashtable.newFrom({"star_particle": gdjs.Level1Code.GDstar_9595particleObjects6});
gdjs.Level1Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemoneObjects5, gdjs.Level1Code.GDcard_9595anemoneObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemone2Objects5, gdjs.Level1Code.GDcard_9595anemone2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfishObjects5, gdjs.Level1Code.GDcard_9595blowfishObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfish2Objects5, gdjs.Level1Code.GDcard_9595blowfish2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coralObjects5, gdjs.Level1Code.GDcard_9595coralObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coral2Objects5, gdjs.Level1Code.GDcard_9595coral2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crabObjects5, gdjs.Level1Code.GDcard_9595crabObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crab2Objects5, gdjs.Level1Code.GDcard_9595crab2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbagObjects5, gdjs.Level1Code.GDcard_9595plasticbagObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbag2Objects5, gdjs.Level1Code.GDcard_9595plasticbag2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrassObjects5, gdjs.Level1Code.GDcard_9595seagrassObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrass2Objects5, gdjs.Level1Code.GDcard_9595seagrass2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorseObjects5, gdjs.Level1Code.GDcard_9595seahorseObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorse2Objects5, gdjs.Level1Code.GDcard_9595seahorse2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snailObjects5, gdjs.Level1Code.GDcard_9595snailObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snail2Objects5, gdjs.Level1Code.GDcard_9595snail2Objects6);

gdjs.Level1Code.GDstar_9595particleObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDstar_95959595particleObjects6Objects, (( gdjs.Level1Code.GDcard_9595plasticbag2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595anemone2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595coral2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seagrass2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595snail2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seahorse2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595crab2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595blowfish2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595plasticbagObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595anemoneObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595coralObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seagrassObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595snailObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seahorseObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595crabObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595blowfishObjects6.length === 0 ) ? 0 :gdjs.Level1Code.GDcard_9595blowfishObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595crabObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595seahorseObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595snailObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595seagrassObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595coralObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595anemoneObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595plasticbagObjects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595blowfish2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595crab2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595seahorse2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595snail2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595seagrass2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595coral2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595anemone2Objects6[0].getPointX("")) :gdjs.Level1Code.GDcard_9595plasticbag2Objects6[0].getPointX("")), (( gdjs.Level1Code.GDcard_9595plasticbag2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595anemone2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595coral2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seagrass2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595snail2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seahorse2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595crab2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595blowfish2Objects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595plasticbagObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595anemoneObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595coralObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seagrassObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595snailObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595seahorseObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595crabObjects6.length === 0 ) ? (( gdjs.Level1Code.GDcard_9595blowfishObjects6.length === 0 ) ? 0 :gdjs.Level1Code.GDcard_9595blowfishObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595crabObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595seahorseObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595snailObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595seagrassObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595coralObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595anemoneObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595plasticbagObjects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595blowfish2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595crab2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595seahorse2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595snail2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595seagrass2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595coral2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595anemone2Objects6[0].getPointY("")) :gdjs.Level1Code.GDcard_9595plasticbag2Objects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Level1Code.GDstar_9595particleObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDstar_9595particleObjects6[i].setZOrder(100);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cuckoo.wav", false, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15546348);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemoneObjects5, gdjs.Level1Code.GDcard_9595anemoneObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595anemone2Objects5, gdjs.Level1Code.GDcard_9595anemone2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfishObjects5, gdjs.Level1Code.GDcard_9595blowfishObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595blowfish2Objects5, gdjs.Level1Code.GDcard_9595blowfish2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coralObjects5, gdjs.Level1Code.GDcard_9595coralObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595coral2Objects5, gdjs.Level1Code.GDcard_9595coral2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crabObjects5, gdjs.Level1Code.GDcard_9595crabObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595crab2Objects5, gdjs.Level1Code.GDcard_9595crab2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbagObjects5, gdjs.Level1Code.GDcard_9595plasticbagObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595plasticbag2Objects5, gdjs.Level1Code.GDcard_9595plasticbag2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrassObjects5, gdjs.Level1Code.GDcard_9595seagrassObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seagrass2Objects5, gdjs.Level1Code.GDcard_9595seagrass2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorseObjects5, gdjs.Level1Code.GDcard_9595seahorseObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595seahorse2Objects5, gdjs.Level1Code.GDcard_9595seahorse2Objects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snailObjects5, gdjs.Level1Code.GDcard_9595snailObjects6);

gdjs.copyArray(gdjs.Level1Code.GDcard_9595snail2Objects5, gdjs.Level1Code.GDcard_9595snail2Objects6);

{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects6.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
}}

}


};gdjs.Level1Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */

gdjs.Level1Code.forEachTotalCount5 = 0;
gdjs.Level1Code.forEachObjects5.length = 0;
gdjs.Level1Code.forEachCount0_5 = gdjs.Level1Code.GDcard_9595blowfishObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount0_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595blowfishObjects4);
gdjs.Level1Code.forEachCount1_5 = gdjs.Level1Code.GDcard_9595crabObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount1_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595crabObjects4);
gdjs.Level1Code.forEachCount2_5 = gdjs.Level1Code.GDcard_9595seahorseObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount2_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595seahorseObjects4);
gdjs.Level1Code.forEachCount3_5 = gdjs.Level1Code.GDcard_9595snailObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount3_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595snailObjects4);
gdjs.Level1Code.forEachCount4_5 = gdjs.Level1Code.GDcard_9595seagrassObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount4_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595seagrassObjects4);
gdjs.Level1Code.forEachCount5_5 = gdjs.Level1Code.GDcard_9595coralObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount5_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595coralObjects4);
gdjs.Level1Code.forEachCount6_5 = gdjs.Level1Code.GDcard_9595anemoneObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount6_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595anemoneObjects4);
gdjs.Level1Code.forEachCount7_5 = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount7_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595plasticbagObjects4);
gdjs.Level1Code.forEachCount8_5 = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount8_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595blowfish2Objects4);
gdjs.Level1Code.forEachCount9_5 = gdjs.Level1Code.GDcard_9595crab2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount9_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595crab2Objects4);
gdjs.Level1Code.forEachCount10_5 = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount10_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595seahorse2Objects4);
gdjs.Level1Code.forEachCount11_5 = gdjs.Level1Code.GDcard_9595snail2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount11_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595snail2Objects4);
gdjs.Level1Code.forEachCount12_5 = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount12_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595seagrass2Objects4);
gdjs.Level1Code.forEachCount13_5 = gdjs.Level1Code.GDcard_9595coral2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount13_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595coral2Objects4);
gdjs.Level1Code.forEachCount14_5 = gdjs.Level1Code.GDcard_9595anemone2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount14_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595anemone2Objects4);
gdjs.Level1Code.forEachCount15_5 = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length;
gdjs.Level1Code.forEachTotalCount5 += gdjs.Level1Code.forEachCount15_5;
gdjs.Level1Code.forEachObjects5.push.apply(gdjs.Level1Code.forEachObjects5,gdjs.Level1Code.GDcard_9595plasticbag2Objects4);
for (gdjs.Level1Code.forEachIndex5 = 0;gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachTotalCount5;++gdjs.Level1Code.forEachIndex5) {
gdjs.Level1Code.GDcard_9595anemoneObjects5.length = 0;

gdjs.Level1Code.GDcard_9595anemone2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595blowfishObjects5.length = 0;

gdjs.Level1Code.GDcard_9595blowfish2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595coralObjects5.length = 0;

gdjs.Level1Code.GDcard_9595coral2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595crabObjects5.length = 0;

gdjs.Level1Code.GDcard_9595crab2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595plasticbagObjects5.length = 0;

gdjs.Level1Code.GDcard_9595plasticbag2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595seagrassObjects5.length = 0;

gdjs.Level1Code.GDcard_9595seagrass2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595seahorseObjects5.length = 0;

gdjs.Level1Code.GDcard_9595seahorse2Objects5.length = 0;

gdjs.Level1Code.GDcard_9595snailObjects5.length = 0;

gdjs.Level1Code.GDcard_9595snail2Objects5.length = 0;


if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5) {
    gdjs.Level1Code.GDcard_9595blowfishObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5) {
    gdjs.Level1Code.GDcard_9595crabObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5) {
    gdjs.Level1Code.GDcard_9595seahorseObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5) {
    gdjs.Level1Code.GDcard_9595snailObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5) {
    gdjs.Level1Code.GDcard_9595seagrassObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5) {
    gdjs.Level1Code.GDcard_9595coralObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5) {
    gdjs.Level1Code.GDcard_9595anemoneObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5) {
    gdjs.Level1Code.GDcard_9595crab2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5+gdjs.Level1Code.forEachCount11_5) {
    gdjs.Level1Code.GDcard_9595snail2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5+gdjs.Level1Code.forEachCount11_5+gdjs.Level1Code.forEachCount12_5) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5+gdjs.Level1Code.forEachCount11_5+gdjs.Level1Code.forEachCount12_5+gdjs.Level1Code.forEachCount13_5) {
    gdjs.Level1Code.GDcard_9595coral2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5+gdjs.Level1Code.forEachCount11_5+gdjs.Level1Code.forEachCount12_5+gdjs.Level1Code.forEachCount13_5+gdjs.Level1Code.forEachCount14_5) {
    gdjs.Level1Code.GDcard_9595anemone2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
else if (gdjs.Level1Code.forEachIndex5 < gdjs.Level1Code.forEachCount0_5+gdjs.Level1Code.forEachCount1_5+gdjs.Level1Code.forEachCount2_5+gdjs.Level1Code.forEachCount3_5+gdjs.Level1Code.forEachCount4_5+gdjs.Level1Code.forEachCount5_5+gdjs.Level1Code.forEachCount6_5+gdjs.Level1Code.forEachCount7_5+gdjs.Level1Code.forEachCount8_5+gdjs.Level1Code.forEachCount9_5+gdjs.Level1Code.forEachCount10_5+gdjs.Level1Code.forEachCount11_5+gdjs.Level1Code.forEachCount12_5+gdjs.Level1Code.forEachCount13_5+gdjs.Level1Code.forEachCount14_5+gdjs.Level1Code.forEachCount15_5) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects5.push(gdjs.Level1Code.forEachObjects5[gdjs.Level1Code.forEachIndex5]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Level1Code.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level1Code.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595blowfishObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects4[k] = gdjs.Level1Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595crabObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects4[k] = gdjs.Level1Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595seahorseObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects4[k] = gdjs.Level1Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595snailObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects4[k] = gdjs.Level1Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595seagrassObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects4[k] = gdjs.Level1Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595coralObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects4[k] = gdjs.Level1Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595anemoneObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects4[k] = gdjs.Level1Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].getVariableString(gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects4[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects4[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595crab2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects4[k] = gdjs.Level1Code.GDcard_9595crab2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects4[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595snail2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects4[k] = gdjs.Level1Code.GDcard_9595snail2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects4[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595coral2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects4[k] = gdjs.Level1Code.GDcard_9595coral2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595anemone2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects4[k] = gdjs.Level1Code.GDcard_9595anemone2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].getVariableString(gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects4[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList11 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects4);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects4ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects4Objects);
}
{ //Subevents
gdjs.Level1Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.Level1Code.GDpairsObjects4);
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Level1Code.GDpairsObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDpairsObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Level1Code.GDpairsObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDpairsObjects4[i].getBehavior("Tween").addObjectColorTween("flash", "179;211;48", "easeInOutQuad", 250, false, false);
}
}
{ //Subevents
gdjs.Level1Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects4[k] = gdjs.Level1Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects4[k] = gdjs.Level1Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects4[k] = gdjs.Level1Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects4[k] = gdjs.Level1Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects4[k] = gdjs.Level1Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects4[k] = gdjs.Level1Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects4[k] = gdjs.Level1Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects4[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects4[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects4[k] = gdjs.Level1Code.GDcard_9595crab2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects4[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects4[k] = gdjs.Level1Code.GDcard_9595snail2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects4[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects4[k] = gdjs.Level1Code.GDcard_9595coral2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects4[k] = gdjs.Level1Code.GDcard_9595anemone2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects4[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15547468);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects4 */
{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.Level1Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Level1Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(4).setString("player_turn");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.Level1Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level1Code.GDcard_9595anemoneObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595anemone2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfishObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595blowfish2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595coralObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595coral2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595crabObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595crab2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbagObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595plasticbag2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrassObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595seagrass2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorseObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595seahorse2Objects1 */
/* Reuse gdjs.Level1Code.GDcard_9595snailObjects1 */
/* Reuse gdjs.Level1Code.GDcard_9595snail2Objects1 */
{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
}{for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crabObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snailObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coralObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595blowfish2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595blowfish2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595crab2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595crab2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seahorse2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seahorse2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595snail2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595snail2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595seagrass2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595seagrass2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595coral2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595coral2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595anemone2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595anemone2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDcard_9595plasticbag2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.Level1Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)) == "player_turn";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects2[k] = gdjs.Level1Code.GDcard_9595blowfishObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects2[k] = gdjs.Level1Code.GDcard_9595crabObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects2[k] = gdjs.Level1Code.GDcard_9595seahorseObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects2[k] = gdjs.Level1Code.GDcard_9595snailObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects2[k] = gdjs.Level1Code.GDcard_9595seagrassObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects2[k] = gdjs.Level1Code.GDcard_9595coralObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects2[k] = gdjs.Level1Code.GDcard_9595anemoneObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects2[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects2[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects2[k] = gdjs.Level1Code.GDcard_9595crab2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects2[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects2[k] = gdjs.Level1Code.GDcard_9595snail2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects2[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects2[k] = gdjs.Level1Code.GDcard_9595coral2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects2[k] = gdjs.Level1Code.GDcard_9595anemone2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects2[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "show_cards") > 1.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15540804);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfishObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfishObjects1[k] = gdjs.Level1Code.GDcard_9595blowfishObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfishObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crabObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crabObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crabObjects1[k] = gdjs.Level1Code.GDcard_9595crabObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crabObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorseObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorseObjects1[k] = gdjs.Level1Code.GDcard_9595seahorseObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorseObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snailObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snailObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snailObjects1[k] = gdjs.Level1Code.GDcard_9595snailObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snailObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrassObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrassObjects1[k] = gdjs.Level1Code.GDcard_9595seagrassObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrassObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coralObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coralObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coralObjects1[k] = gdjs.Level1Code.GDcard_9595coralObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coralObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemoneObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemoneObjects1[k] = gdjs.Level1Code.GDcard_9595anemoneObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemoneObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbagObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbagObjects1[k] = gdjs.Level1Code.GDcard_9595plasticbagObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbagObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595blowfish2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595blowfish2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595blowfish2Objects1[k] = gdjs.Level1Code.GDcard_9595blowfish2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595blowfish2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595crab2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595crab2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595crab2Objects1[k] = gdjs.Level1Code.GDcard_9595crab2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595crab2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seahorse2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seahorse2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seahorse2Objects1[k] = gdjs.Level1Code.GDcard_9595seahorse2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seahorse2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595snail2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595snail2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595snail2Objects1[k] = gdjs.Level1Code.GDcard_9595snail2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595snail2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595seagrass2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595seagrass2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595seagrass2Objects1[k] = gdjs.Level1Code.GDcard_9595seagrass2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595seagrass2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595coral2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595coral2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595coral2Objects1[k] = gdjs.Level1Code.GDcard_9595coral2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595coral2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595anemone2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595anemone2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595anemone2Objects1[k] = gdjs.Level1Code.GDcard_9595anemone2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595anemone2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDcard_9595plasticbag2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDcard_9595plasticbag2Objects1[k] = gdjs.Level1Code.GDcard_9595plasticbag2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15550396);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDnewgame_95959595buttonObjects2Objects = Hashtable.newFrom({"newgame_button": gdjs.Level1Code.GDnewgame_9595buttonObjects2});
gdjs.Level1Code.eventsList16 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15556428);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDnewgame_9595buttonObjects2, gdjs.Level1Code.GDnewgame_9595buttonObjects3);

{for(var i = 0, len = gdjs.Level1Code.GDnewgame_9595buttonObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgame_9595buttonObjects3[i].getBehavior("Tween").addObjectColorTween("shine", "255;255;255", "easeFromTo", 500, false, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/pop.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDnewgame_95959595buttonObjects1Objects = Hashtable.newFrom({"newgame_button": gdjs.Level1Code.GDnewgame_9595buttonObjects1});
gdjs.Level1Code.eventsList17 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15558932);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDnewgame_9595buttonObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDnewgame_9595buttonObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgame_9595buttonObjects1[i].getBehavior("Tween").addObjectColorTween("shine", "200;200;200", "easeFromTo", 500, false, false);
}
}}

}


};gdjs.Level1Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15553460);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("newgame"), gdjs.Level1Code.GDnewgameObjects2);
gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Level1Code.GDnewgame_9595buttonObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDnewgame_9595buttonObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgame_9595buttonObjects2[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.Level1Code.GDnewgame_9595buttonObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgame_9595buttonObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button", 1, 1, "elastic", 1500, false, false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgameObjects2[i].setScaleX(0.5);
}
}{for(var i = 0, len = gdjs.Level1Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgameObjects2[i].setScaleY(0.5);
}
}{for(var i = 0, len = gdjs.Level1Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDnewgameObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button_text", 1, 1, "elastic", 1500, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Level1Code.GDnewgame_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDnewgame_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Level1Code.GDnewgame_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDnewgame_95959595buttonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList19 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.Level1Code.GDpairsObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDpairsObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDpairsObjects2[i].setString("Pairs: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "UI");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects1Objects = Hashtable.newFrom({"card_blowfish": gdjs.Level1Code.GDcard_9595blowfishObjects1, "card_crab": gdjs.Level1Code.GDcard_9595crabObjects1, "card_seahorse": gdjs.Level1Code.GDcard_9595seahorseObjects1, "card_snail": gdjs.Level1Code.GDcard_9595snailObjects1, "card_seagrass": gdjs.Level1Code.GDcard_9595seagrassObjects1, "card_coral": gdjs.Level1Code.GDcard_9595coralObjects1, "card_anemone": gdjs.Level1Code.GDcard_9595anemoneObjects1, "card_plasticbag": gdjs.Level1Code.GDcard_9595plasticbagObjects1, "card_blowfish2": gdjs.Level1Code.GDcard_9595blowfish2Objects1, "card_crab2": gdjs.Level1Code.GDcard_9595crab2Objects1, "card_seahorse2": gdjs.Level1Code.GDcard_9595seahorse2Objects1, "card_snail2": gdjs.Level1Code.GDcard_9595snail2Objects1, "card_seagrass2": gdjs.Level1Code.GDcard_9595seagrass2Objects1, "card_coral2": gdjs.Level1Code.GDcard_9595coral2Objects1, "card_anemone2": gdjs.Level1Code.GDcard_9595anemone2Objects1, "card_plasticbag2": gdjs.Level1Code.GDcard_9595plasticbag2Objects1});
gdjs.Level1Code.eventsList20 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level1Code.GDui_9595backgroundObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDui_9595backgroundObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDui_9595backgroundObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_out", 175, "linear", 1000, false);
}
}}

}


};gdjs.Level1Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Level1Code.GDcard_9595anemoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_anemone2"), gdjs.Level1Code.GDcard_9595anemone2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Level1Code.GDcard_9595blowfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish2"), gdjs.Level1Code.GDcard_9595blowfish2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Level1Code.GDcard_9595coralObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral2"), gdjs.Level1Code.GDcard_9595coral2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Level1Code.GDcard_9595crabObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab2"), gdjs.Level1Code.GDcard_9595crab2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Level1Code.GDcard_9595plasticbagObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag2"), gdjs.Level1Code.GDcard_9595plasticbag2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Level1Code.GDcard_9595seagrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass2"), gdjs.Level1Code.GDcard_9595seagrass2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Level1Code.GDcard_9595seahorseObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse2"), gdjs.Level1Code.GDcard_9595seahorse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Level1Code.GDcard_9595snailObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail2"), gdjs.Level1Code.GDcard_9595snail2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDcard_95959595blowfishObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crabObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorseObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snailObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrassObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coralObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemoneObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbagObjects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595blowfish2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595crab2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seahorse2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595snail2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595seagrass2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595coral2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595anemone2Objects1ObjectsGDgdjs_9546Level1Code_9546GDcard_95959595plasticbag2Objects1Objects) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15560204);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ui_background"), gdjs.Level1Code.GDui_9595backgroundObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/Rise.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDui_9595backgroundObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDui_9595backgroundObjects1[i].setOpacity(0);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "timer");
}
{ //Subevents
gdjs.Level1Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCloseButtonObjects1Objects = Hashtable.newFrom({"CloseButton": gdjs.Level1Code.GDCloseButtonObjects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPurpleButtonWithStoneFrameObjects1Objects = Hashtable.newFrom({"PurpleButtonWithStoneFrame": gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1});
gdjs.Level1Code.eventsList22 = function(runtimeScene) {

{


gdjs.Level1Code.eventsList3(runtimeScene);
}


{


gdjs.Level1Code.eventsList15(runtimeScene);
}


{


gdjs.Level1Code.eventsList19(runtimeScene);
}


{


gdjs.Level1Code.eventsList21(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite2"), gdjs.Level1Code.GDNewTiledSprite2Objects1);
{for(var i = 0, len = gdjs.Level1Code.GDNewTiledSprite2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNewTiledSprite2Objects1[i].setXOffset(gdjs.Level1Code.GDNewTiledSprite2Objects1[i].getXOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CloseButton"), gdjs.Level1Code.GDCloseButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCloseButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDCloseButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DesertTile"), gdjs.Level1Code.GDDesertTileObjects1);
gdjs.copyArray(runtimeScene.getObjects("petunjuk"), gdjs.Level1Code.GDpetunjukObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDCloseButtonObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCloseButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDDesertTileObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDesertTileObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDpetunjukObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDpetunjukObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Level1Code.GDNewTextObjects1);
{runtimeScene.getScene().getVariables().get("timer").setNumber(360 - gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timer"));
}{for(var i = 0, len = gdjs.Level1Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNewTextObjects1[i].setString("timer :" + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("timer")))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("timer")) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Level1Code.GDNewSprite2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PurpleButtonWithStoneFrame"), gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1);
gdjs.copyArray(runtimeScene.getObjects("gameover_sw"), gdjs.Level1Code.GDgameover_9595swObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNewSprite2Objects1[i].getBehavior("Tween").addObjectPositionYTween("gameover", 0, "easeOutQuad", 1000, false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDgameover_9595swObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDgameover_9595swObjects1[i].getBehavior("Tween").addObjectPositionYTween("gameover", 100, "easeOutQuad", 1000, false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1[i].getBehavior("Tween").addObjectPositionYTween("gameover", 200, "easeOutQuad", 1000, false);
}
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "timer");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PurpleButtonWithStoneFrame"), gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPurpleButtonWithStoneFrameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDcard_9595crabObjects1.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects2.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects3.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects4.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects5.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects6.length = 0;
gdjs.Level1Code.GDcard_9595crabObjects7.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595crab2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects1.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects2.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects3.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects4.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects5.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects6.length = 0;
gdjs.Level1Code.GDcard_9595seahorseObjects7.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595seahorse2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects1.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects2.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects3.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects4.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects5.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects6.length = 0;
gdjs.Level1Code.GDcard_9595snailObjects7.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595snail2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects1.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects2.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects3.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects4.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects5.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects6.length = 0;
gdjs.Level1Code.GDcard_9595seagrassObjects7.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595seagrass2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects1.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects2.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects3.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects4.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects5.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects6.length = 0;
gdjs.Level1Code.GDcard_9595coralObjects7.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595coral2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects1.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects2.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects3.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects4.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects5.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects6.length = 0;
gdjs.Level1Code.GDcard_9595anemoneObjects7.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595anemone2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects1.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects2.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects3.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects4.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects5.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects6.length = 0;
gdjs.Level1Code.GDcard_9595plasticbagObjects7.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595plasticbag2Objects7.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects1.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects2.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects3.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects4.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects5.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects6.length = 0;
gdjs.Level1Code.GDcard_9595blowfishObjects7.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects1.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects2.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects3.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects4.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects5.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects6.length = 0;
gdjs.Level1Code.GDcard_9595blowfish2Objects7.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects1.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects2.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects3.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects4.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects5.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects6.length = 0;
gdjs.Level1Code.GDposition_9595placeholderObjects7.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects1.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects2.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects3.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects4.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects5.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects6.length = 0;
gdjs.Level1Code.GDnewgame_9595buttonObjects7.length = 0;
gdjs.Level1Code.GDboardObjects1.length = 0;
gdjs.Level1Code.GDboardObjects2.length = 0;
gdjs.Level1Code.GDboardObjects3.length = 0;
gdjs.Level1Code.GDboardObjects4.length = 0;
gdjs.Level1Code.GDboardObjects5.length = 0;
gdjs.Level1Code.GDboardObjects6.length = 0;
gdjs.Level1Code.GDboardObjects7.length = 0;
gdjs.Level1Code.GDpairsObjects1.length = 0;
gdjs.Level1Code.GDpairsObjects2.length = 0;
gdjs.Level1Code.GDpairsObjects3.length = 0;
gdjs.Level1Code.GDpairsObjects4.length = 0;
gdjs.Level1Code.GDpairsObjects5.length = 0;
gdjs.Level1Code.GDpairsObjects6.length = 0;
gdjs.Level1Code.GDpairsObjects7.length = 0;
gdjs.Level1Code.GDnewgameObjects1.length = 0;
gdjs.Level1Code.GDnewgameObjects2.length = 0;
gdjs.Level1Code.GDnewgameObjects3.length = 0;
gdjs.Level1Code.GDnewgameObjects4.length = 0;
gdjs.Level1Code.GDnewgameObjects5.length = 0;
gdjs.Level1Code.GDnewgameObjects6.length = 0;
gdjs.Level1Code.GDnewgameObjects7.length = 0;
gdjs.Level1Code.GDyouwonObjects1.length = 0;
gdjs.Level1Code.GDyouwonObjects2.length = 0;
gdjs.Level1Code.GDyouwonObjects3.length = 0;
gdjs.Level1Code.GDyouwonObjects4.length = 0;
gdjs.Level1Code.GDyouwonObjects5.length = 0;
gdjs.Level1Code.GDyouwonObjects6.length = 0;
gdjs.Level1Code.GDyouwonObjects7.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects1.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects2.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects3.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects4.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects5.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects6.length = 0;
gdjs.Level1Code.GDstar_9595particleObjects7.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects1.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects2.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects3.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects4.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects5.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects6.length = 0;
gdjs.Level1Code.GDscreen_9595fadeObjects7.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects1.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects2.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects3.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects4.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects5.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects6.length = 0;
gdjs.Level1Code.GDui_9595backgroundObjects7.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects6.length = 0;
gdjs.Level1Code.GDNewTiledSpriteObjects7.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects3.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects4.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects5.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects6.length = 0;
gdjs.Level1Code.GDNewTiledSprite2Objects7.length = 0;
gdjs.Level1Code.GDNewSpriteObjects1.length = 0;
gdjs.Level1Code.GDNewSpriteObjects2.length = 0;
gdjs.Level1Code.GDNewSpriteObjects3.length = 0;
gdjs.Level1Code.GDNewSpriteObjects4.length = 0;
gdjs.Level1Code.GDNewSpriteObjects5.length = 0;
gdjs.Level1Code.GDNewSpriteObjects6.length = 0;
gdjs.Level1Code.GDNewSpriteObjects7.length = 0;
gdjs.Level1Code.GDDesertTileObjects1.length = 0;
gdjs.Level1Code.GDDesertTileObjects2.length = 0;
gdjs.Level1Code.GDDesertTileObjects3.length = 0;
gdjs.Level1Code.GDDesertTileObjects4.length = 0;
gdjs.Level1Code.GDDesertTileObjects5.length = 0;
gdjs.Level1Code.GDDesertTileObjects6.length = 0;
gdjs.Level1Code.GDDesertTileObjects7.length = 0;
gdjs.Level1Code.GDpetunjukObjects1.length = 0;
gdjs.Level1Code.GDpetunjukObjects2.length = 0;
gdjs.Level1Code.GDpetunjukObjects3.length = 0;
gdjs.Level1Code.GDpetunjukObjects4.length = 0;
gdjs.Level1Code.GDpetunjukObjects5.length = 0;
gdjs.Level1Code.GDpetunjukObjects6.length = 0;
gdjs.Level1Code.GDpetunjukObjects7.length = 0;
gdjs.Level1Code.GDCloseButtonObjects1.length = 0;
gdjs.Level1Code.GDCloseButtonObjects2.length = 0;
gdjs.Level1Code.GDCloseButtonObjects3.length = 0;
gdjs.Level1Code.GDCloseButtonObjects4.length = 0;
gdjs.Level1Code.GDCloseButtonObjects5.length = 0;
gdjs.Level1Code.GDCloseButtonObjects6.length = 0;
gdjs.Level1Code.GDCloseButtonObjects7.length = 0;
gdjs.Level1Code.GDNewTextObjects1.length = 0;
gdjs.Level1Code.GDNewTextObjects2.length = 0;
gdjs.Level1Code.GDNewTextObjects3.length = 0;
gdjs.Level1Code.GDNewTextObjects4.length = 0;
gdjs.Level1Code.GDNewTextObjects5.length = 0;
gdjs.Level1Code.GDNewTextObjects6.length = 0;
gdjs.Level1Code.GDNewTextObjects7.length = 0;
gdjs.Level1Code.GDcopyrightObjects1.length = 0;
gdjs.Level1Code.GDcopyrightObjects2.length = 0;
gdjs.Level1Code.GDcopyrightObjects3.length = 0;
gdjs.Level1Code.GDcopyrightObjects4.length = 0;
gdjs.Level1Code.GDcopyrightObjects5.length = 0;
gdjs.Level1Code.GDcopyrightObjects6.length = 0;
gdjs.Level1Code.GDcopyrightObjects7.length = 0;
gdjs.Level1Code.GDNewSprite2Objects1.length = 0;
gdjs.Level1Code.GDNewSprite2Objects2.length = 0;
gdjs.Level1Code.GDNewSprite2Objects3.length = 0;
gdjs.Level1Code.GDNewSprite2Objects4.length = 0;
gdjs.Level1Code.GDNewSprite2Objects5.length = 0;
gdjs.Level1Code.GDNewSprite2Objects6.length = 0;
gdjs.Level1Code.GDNewSprite2Objects7.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects1.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects2.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects3.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects4.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects5.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects6.length = 0;
gdjs.Level1Code.GDgameover_9595swObjects7.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects1.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects2.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects3.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects4.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects5.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects6.length = 0;
gdjs.Level1Code.GDPurpleButtonWithStoneFrameObjects7.length = 0;
gdjs.Level1Code.GDNewSprite3Objects1.length = 0;
gdjs.Level1Code.GDNewSprite3Objects2.length = 0;
gdjs.Level1Code.GDNewSprite3Objects3.length = 0;
gdjs.Level1Code.GDNewSprite3Objects4.length = 0;
gdjs.Level1Code.GDNewSprite3Objects5.length = 0;
gdjs.Level1Code.GDNewSprite3Objects6.length = 0;
gdjs.Level1Code.GDNewSprite3Objects7.length = 0;

gdjs.Level1Code.eventsList22(runtimeScene);

return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
