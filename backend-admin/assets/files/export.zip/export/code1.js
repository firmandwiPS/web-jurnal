gdjs.dialogCode = {};
gdjs.dialogCode.GDbgdialogObjects1= [];
gdjs.dialogCode.GDbgdialogObjects2= [];
gdjs.dialogCode.GDbgdialogObjects3= [];
gdjs.dialogCode.GDmimigirlObjects1= [];
gdjs.dialogCode.GDmimigirlObjects2= [];
gdjs.dialogCode.GDmimigirlObjects3= [];
gdjs.dialogCode.GDsiwogirlObjects1= [];
gdjs.dialogCode.GDsiwogirlObjects2= [];
gdjs.dialogCode.GDsiwogirlObjects3= [];
gdjs.dialogCode.GDdialogObjects1= [];
gdjs.dialogCode.GDdialogObjects2= [];
gdjs.dialogCode.GDdialogObjects3= [];
gdjs.dialogCode.GDBrownPanelObjects1= [];
gdjs.dialogCode.GDBrownPanelObjects2= [];
gdjs.dialogCode.GDBrownPanelObjects3= [];
gdjs.dialogCode.GDNametextObjects1= [];
gdjs.dialogCode.GDNametextObjects2= [];
gdjs.dialogCode.GDNametextObjects3= [];
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1= [];
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects2= [];
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects3= [];


gdjs.dialogCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "percakapan") >= 0.05;
if (isConditionTrue_0) {
{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "percakapan");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


};gdjs.dialogCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "New dialogue tree");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "percakapan");
}{gdjs.dialogueTree.startFrom("Start");
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-driving-ambition-32.mp3", false, 1, 100);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dialog"), gdjs.dialogCode.GDdialogObjects1);
{for(var i = 0, len = gdjs.dialogCode.GDdialogObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDdialogObjects1[i].setBBText(gdjs.dialogueTree.getClippedLineText());
}
}
{ //Subevents
gdjs.dialogCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isCommandCalled("Tava");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nametext"), gdjs.dialogCode.GDNametextObjects1);
{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setBBText("[b]Tava[/b]");
}
}{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setX(300);
}
}{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setY(200);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isCommandCalled("Prana");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nametext"), gdjs.dialogCode.GDNametextObjects1);
{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setBBText("[b]Prana[/b]");
}
}{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setX(650);
}
}{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setY(370);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isCommandCalled("Stop");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nametext"), gdjs.dialogCode.GDNametextObjects1);
gdjs.copyArray(runtimeScene.getObjects("WhiteSquareDecoratedButton"), gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1);
{for(var i = 0, len = gdjs.dialogCode.GDNametextObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDNametextObjects1[i].setBBText("");
}
}{for(var i = 0, len = gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1[i].getBehavior("Tween").addObjectPositionYTween("tombolgerak", 517, "easeInOutQuad", 500, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquareDecoratedButton"), gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1[k] = gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};

gdjs.dialogCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.dialogCode.GDbgdialogObjects1.length = 0;
gdjs.dialogCode.GDbgdialogObjects2.length = 0;
gdjs.dialogCode.GDbgdialogObjects3.length = 0;
gdjs.dialogCode.GDmimigirlObjects1.length = 0;
gdjs.dialogCode.GDmimigirlObjects2.length = 0;
gdjs.dialogCode.GDmimigirlObjects3.length = 0;
gdjs.dialogCode.GDsiwogirlObjects1.length = 0;
gdjs.dialogCode.GDsiwogirlObjects2.length = 0;
gdjs.dialogCode.GDsiwogirlObjects3.length = 0;
gdjs.dialogCode.GDdialogObjects1.length = 0;
gdjs.dialogCode.GDdialogObjects2.length = 0;
gdjs.dialogCode.GDdialogObjects3.length = 0;
gdjs.dialogCode.GDBrownPanelObjects1.length = 0;
gdjs.dialogCode.GDBrownPanelObjects2.length = 0;
gdjs.dialogCode.GDBrownPanelObjects3.length = 0;
gdjs.dialogCode.GDNametextObjects1.length = 0;
gdjs.dialogCode.GDNametextObjects2.length = 0;
gdjs.dialogCode.GDNametextObjects3.length = 0;
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.dialogCode.GDWhiteSquareDecoratedButtonObjects3.length = 0;

gdjs.dialogCode.eventsList1(runtimeScene);

return;

}

gdjs['dialogCode'] = gdjs.dialogCode;
